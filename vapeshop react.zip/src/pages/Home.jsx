// @ts-nocheck
import React from "react";
import Item from "../components/Item";
import Header from "../components/Header";
import Footer from "../components/Footer";
import MobileNav from "../components/MobileNav";
import TopHeader from "../components/TopHeader";
import ItemModel from "../components/ItemModel";
import StoreFeature from "../components/StoreFeature";
import Banner from "../components/Banner";

export default function Home() {
  return (
    <>
      <div className="pageWrapper">
        <TopHeader />
        <Header />
        <MobileNav />
        <div id="page-content">
          <Banner />
          <div className="product-rows section">
            <div className="container">
              <div className="row">
                <div className="col-12 col-sm-12 col-md-12 col-lg-12">
                  <div className="section-header text-center">
                    <h2 className="h2">Featured collection</h2>
                    <p>Our most popular products based on sales</p>
                  </div>
                </div>
              </div>
              <div className="grid-products">
                <div className="row">
                  <Item />
                  <Item />
                  <Item />
                </div>
              </div>
            </div>
          </div>
          <StoreFeature />
        </div>
        <Footer />
        <ItemModel />
      </div>
    </>
  );
}
