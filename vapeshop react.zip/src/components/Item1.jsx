import React from "react";
import { Link } from "react-router-dom";
import Product from "../pages/Product";

export default function Item1() {
  return (
    <>
      <div class="col-6 col-sm-6 col-md-4 col-lg-3 item">
        <div class="product-image">
          <a href="#">
            <img
              class="primary blur-up lazyload"
              data-src="assets/images/product-images/product-image4.jpg"
              src="assets/images/product-images/product-image4.jpg"
              alt="image"
              title="product"
            />

            <img
              class="hover blur-up lazyload"
              data-src="assets/images/product-images/product-image4-1.jpg"
              src="assets/images/product-images/product-image4-1.jpg"
              alt="image"
              title="product"
            />

            <div class="product-labels">
              <span class="lbl on-sale">Sale</span>
            </div>
          </a>

          <form
            class="variants add"
            action="#"
            onclick="window.location.href='cart.html'"
            method="post"
          >
            <Link to='/product' class="btn btn-addto-cart" type="button">
              Add To Cart
            </Link>
          </form>
          <div class="button-set">
            <a
              href="javascript:void(0)"
              title="Quick View"
              class="quick-view-popup quick-view"
              data-toggle="modal"
              data-target="#content_quickview"
            >
              <i class="icon anm anm-search-plus-r"></i>
            </a>
            <div class="wishlist-btn">
              <a
                class="wishlist add-to-wishlist"
                href="#"
                title="Add to Wishlist"
              >
                <i class="icon anm anm-heart-l"></i>
              </a>
            </div>
            <div class="compare-btn">
              <a
                class="compare add-to-compare"
                href="compare.html"
                title="Add to Compare"
              >
                <i class="icon anm anm-random-r"></i>
              </a>
            </div>
          </div>
        </div>

        <div class="product-details text-center">
          <div class="product-name">
            <a href="#">Cape Dress</a>
          </div>

          <div class="product-price">
            <span class="old-price">$900.00</span>
            <span class="price">$788.00</span>
          </div>

          <div class="product-review">
            <i class="font-13 fa fa-star"></i>
            <i class="font-13 fa fa-star"></i>
            <i class="font-13 fa fa-star"></i>
            <i class="font-13 fa fa-star-o"></i>
            <i class="font-13 fa fa-star-o"></i>
          </div>

          <ul class="swatches">
            <li class="swatch medium rounded">
              <img
                src="assets/images/product-images/variant4-1.jpg"
                alt="image"
              />
            </li>
            <li class="swatch medium rounded">
              <img
                src="assets/images/product-images/variant4-2.jpg"
                alt="image"
              />
            </li>
            <li class="swatch medium rounded">
              <img
                src="assets/images/product-images/variant4-3.jpg"
                alt="image"
              />
            </li>
            <li class="swatch medium rounded">
              <img
                src="assets/images/product-images/variant4-4.jpg"
                alt="image"
              />
            </li>
          </ul>
        </div>
      </div>
    </>
  );
}
