import React from "react";
export default function ShopFilter() {
  return (
    <>
      <div class="col-12 col-sm-12 col-md-3 col-lg-3 sidebar filterbar">
        <div class="closeFilter d-block d-md-none d-lg-none">
          <i class="icon icon anm anm-times-l"></i>
        </div>
        <div class="sidebar_tags">
          <div class="sidebar_widget categories filter-widget">
            <div class="widget-title">
              <h2>Categories</h2>
            </div>
            <div class="widget-content">
              <ul class="sidebar_categories">
                <li class="level1 sub-level">
                  <a href="#;" class="site-nav">
                    Clothing
                  </a>
                  <ul class="sublinks">
                    <li class="level2">
                      <a href="#;" class="site-nav">
                        Men
                      </a>
                    </li>
                    <li class="level2">
                      <a href="#;" class="site-nav">
                        Women
                      </a>
                    </li>
                    <li class="level2">
                      <a href="#;" class="site-nav">
                        Child
                      </a>
                    </li>
                    <li class="level2">
                      <a href="#;" class="site-nav">
                        View All Clothing
                      </a>
                    </li>
                  </ul>
                </li>
                <li class="level1 sub-level">
                  <a href="#;" class="site-nav">
                    Jewellery
                  </a>
                  <ul class="sublinks">
                    <li class="level2">
                      <a href="#;" class="site-nav">
                        Ring
                      </a>
                    </li>
                    <li class="level2">
                      <a href="#;" class="site-nav">
                        Neckalses
                      </a>
                    </li>
                    <li class="level2">
                      <a href="#;" class="site-nav">
                        Eaarings
                      </a>
                    </li>
                    <li class="level2">
                      <a href="#;" class="site-nav">
                        View All Jewellery
                      </a>
                    </li>
                  </ul>
                </li>
                <li class="lvl-1">
                  <a href="#;" class="site-nav">
                    Shoes
                  </a>
                </li>
                <li class="lvl-1">
                  <a href="#;" class="site-nav">
                    Accessories
                  </a>
                </li>
                <li class="lvl-1">
                  <a href="#;" class="site-nav">
                    Collections
                  </a>
                </li>
                <li class="lvl-1">
                  <a href="#;" class="site-nav">
                    Sale
                  </a>
                </li>
                <li class="lvl-1">
                  <a href="#;" class="site-nav">
                    Page
                  </a>
                </li>
              </ul>
            </div>
          </div>
          <div class="sidebar_widget filterBox filter-widget">
            <div class="widget-title">
              <h2>Color</h2>
            </div>
            <div class="filter-color swacth-list clearfix">
              <span class="swacth-btn black"></span>
              <span class="swacth-btn white checked"></span>
              <span class="swacth-btn red"></span>
              <span class="swacth-btn blue"></span>
              <span class="swacth-btn pink"></span>
              <span class="swacth-btn gray"></span>
              <span class="swacth-btn green"></span>
              <span class="swacth-btn orange"></span>
              <span class="swacth-btn yellow"></span>
              <span class="swacth-btn blueviolet"></span>
              <span class="swacth-btn brown"></span>
              <span class="swacth-btn darkGoldenRod"></span>
              <span class="swacth-btn darkGreen"></span>
              <span class="swacth-btn darkRed"></span>
              <span class="swacth-btn dimGrey"></span>
              <span class="swacth-btn khaki"></span>
            </div>
          </div>
        </div>
      </div>
    </>
  );
}
